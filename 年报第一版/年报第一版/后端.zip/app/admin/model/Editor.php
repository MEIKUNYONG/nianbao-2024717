<?php 
/*
 module:		编辑器控制器
 create_time:	2022-08-19 16:30:59
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class Editor extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'editor_id';

 	protected $name = 'editor';




}

