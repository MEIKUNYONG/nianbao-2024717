<?php 


namespace app\admin\model;
use think\Model;

class EnterpriseReport extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'id';

 	protected $name = 'enterprise_report';




}

