<?php 
/*
 module:		友情链接分类控制器
 create_time:	2022-08-19 16:52:13
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class Linkcata extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'linkcata_id';

 	protected $name = 'linkcata';




}

