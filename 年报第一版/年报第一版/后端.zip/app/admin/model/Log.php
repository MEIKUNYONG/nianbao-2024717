<?php 
/*
 module:		日志管理控制器
 create_time:	2022-05-26 09:46:19
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class Log extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'id';

 	protected $name = 'log';




}

