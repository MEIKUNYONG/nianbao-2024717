<?php 
/*
 module:		再加一种弹窗控制器
 create_time:	2022-08-19 16:40:44
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class Mem2 extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'membe_id';

 	protected $name = 'membe';




}

