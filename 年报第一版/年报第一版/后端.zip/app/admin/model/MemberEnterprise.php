<?php 


namespace app\admin\model;
use think\Model;

class MemberEnterprise extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'id';

 	protected $name = 'member_enterprise';




}

