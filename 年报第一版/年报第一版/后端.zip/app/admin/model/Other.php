<?php 
/*
 module:		其它常用控制器
 create_time:	2022-08-19 16:49:48
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class Other extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'other_id';

 	protected $name = 'other';




}

