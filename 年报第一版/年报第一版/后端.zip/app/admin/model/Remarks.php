<?php 


namespace app\admin\model;
use think\Model;

class Remarks extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'id';

 	protected $name = 'remarks';




}

