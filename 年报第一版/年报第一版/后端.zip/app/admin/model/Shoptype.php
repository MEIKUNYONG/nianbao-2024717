<?php 

namespace app\admin\model;
use think\Model;

class Shoptype extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'id';

 	protected $name = 'shop_type';




}

