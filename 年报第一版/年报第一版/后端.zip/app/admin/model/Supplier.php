<?php 
/*
 module:		供应商管理控制器
 create_time:	2022-07-11 16:28:27
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class Supplier extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'supplier_id';

 	protected $name = 'supplier';




}

