<?php 
/*
 module:		基本配置控制器
 create_time:	2022-08-10 18:44:12
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Baseconfig extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
		'index'=>[''],
	];



}

