<?php 
/*
 module:		批量操作控制器
 create_time:	2022-08-19 16:48:15
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Batch extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
		'add'=>[''],
		'update'=>[''],
	];



}

