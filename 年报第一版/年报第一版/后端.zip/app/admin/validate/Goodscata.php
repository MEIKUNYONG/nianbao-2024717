<?php 
/*
 module:		商品分类控制器
 create_time:	2022-07-11 16:28:25
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Goodscata extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
		'add'=>[''],
		'update'=>[''],
	];



}

