<?php 
/*
 module:		友情链接控制器
 create_time:	2022-08-19 17:08:28
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Link extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
		'add'=>[''],
		'update'=>[''],
	];



}

