<?php 
/*
 module:		日志管理控制器
 create_time:	2022-05-26 09:46:19
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Log extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
	];



}

