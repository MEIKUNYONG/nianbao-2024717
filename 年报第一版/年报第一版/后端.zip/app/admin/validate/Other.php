<?php 
/*
 module:		其它常用控制器
 create_time:	2022-08-19 16:49:48
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Other extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
		'add'=>[''],
		'update'=>[''],
	];



}

