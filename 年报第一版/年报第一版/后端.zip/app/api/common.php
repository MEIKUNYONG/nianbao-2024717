<?php

declare (strict_types = 1);
error_reporting(0);

