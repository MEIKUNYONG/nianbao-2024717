<?php
return array (
  'ext' => 
  array (
    'user' => 'png,jpg',
  ),
  'size' => 
  array (
    'user' => 5242880,
  ),
);