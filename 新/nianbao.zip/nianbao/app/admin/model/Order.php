<?php 


namespace app\admin\model;
use think\Model;

class Order extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'id';

 	protected $name = 'order';




}

