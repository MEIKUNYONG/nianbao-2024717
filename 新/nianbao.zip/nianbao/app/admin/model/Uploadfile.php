<?php 
/*
 module:		上传组件控制器
 create_time:	2022-08-19 16:34:52
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class Uploadfile extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'uploadfile_id';

 	protected $name = 'uploadfile';




}

