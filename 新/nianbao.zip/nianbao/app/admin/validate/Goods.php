<?php 
/*
 module:		商品管理控制器
 create_time:	2022-07-15 11:43:09
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Goods extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
		'add'=>[''],
		'update'=>[''],
	];



}

