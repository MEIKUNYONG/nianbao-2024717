<?php 
/*
 module:		友情链接分类控制器
 create_time:	2022-08-19 16:52:13
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Linkcata extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
		'add'=>[''],
		'update'=>[''],
	];



}

