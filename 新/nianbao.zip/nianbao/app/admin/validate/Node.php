<?php 
/*
 module:		节点管理控制器
 create_time:	2022-08-19 17:20:31
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Node extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
		'add'=>[''],
		'update'=>[''],
	];



}

