/**
 * @description 命令配置项
 * @author wangfupeng
 */
declare const _default: {
    styleWithCSS: boolean;
};
export default _default;
