/**
 * @description 粘贴，配置文件
 * @author wangfupeng
 */
declare const _default: {
    pasteFilterStyle: boolean;
    pasteIgnoreImg: boolean;
    pasteTextHandle: (content: string) => string;
};
export default _default;
