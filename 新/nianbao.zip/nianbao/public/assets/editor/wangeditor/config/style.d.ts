/**
 * @description 样式配置
 * @author wangfupeng
 */
declare const _default: {
    zIndex: number;
};
export default _default;
