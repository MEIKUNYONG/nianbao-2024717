/**
 * @description 绑定编辑器事件 change blur focus
 * @author wangfupeng
 */
import Editor from '../index';
declare function bindEvent(editor: Editor): void;
export default bindEvent;
