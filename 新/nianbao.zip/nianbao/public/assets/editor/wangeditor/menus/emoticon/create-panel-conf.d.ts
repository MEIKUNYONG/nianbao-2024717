/**
 * @description  表情菜单 panel配置
 * @author liuwei
 */
import Editor from '../../editor/index';
import { PanelConf } from '../menu-constructors/Panel';
export default function (editor: Editor): PanelConf;
